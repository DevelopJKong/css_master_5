# Installation
> `npm install --save @types/minimatch`

# Summary
This package contains type definitions for Minimatch (https://github.com/isaacs/minimatch).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/minimatch.

### Additional Details
 * Last updated: Thu, 25 Mar 2021 02:21:11 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [vvakame](https://github.com/vvakame), and [Shant Marouti](https://github.com/shantmarouti).
